/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.vanier.HitTheTarget.controllers;

import javafx.stage.Stage;

/**
 *
 * @author maesh
 */
public class MenuAppController {
    Stage primaryStage;

    public MenuAppController(Stage primaryStage) {
        this.primaryStage = primaryStage;
    }

    public MenuAppController() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    
}
